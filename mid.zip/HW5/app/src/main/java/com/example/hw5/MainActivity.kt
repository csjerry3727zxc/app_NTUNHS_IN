package com.example.hw5

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val spinner = findViewById<Spinner>(R.id.spinner)
        val spinner2 = findViewById<Spinner>(R.id.spinner2)
        val adapter = ArrayAdapter.createFromResource(
            this, R.array.number,
            android.R.layout.simple_spinner_dropdown_item
        )
        val checkBox = findViewById<CheckBox>(R.id.checkBox)
        val checkBox3 = findViewById<CheckBox>(R.id.checkBox3)


        spinner.adapter = adapter
        spinner2.adapter = adapter

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, pos: Int, id: Long) {
                val number = resources.getStringArray(R.array.number)
                if (pos > 0)
                    Toast.makeText(this@MainActivity, "你選的是" + number[pos], Toast.LENGTH_SHORT)
                        .show()


            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }


        val btnGuessnumber = findViewById<Button>(R.id.btnGuessnumber)

        val edtName = findViewById<AutoCompleteTextView>(R.id.edtName)

        btnGuessnumber.setOnClickListener{
            val bundle = Bundle()
            val name = edtName.text.toString()
            val spinner1SelectedItem = spinner.selectedItem.toString()
            val spinner2SelectedItem = spinner2.selectedItem.toString()
            val isChildChairChecked = checkBox.isChecked
            val isChildUtensilChecked = checkBox3.isChecked

            // 设置需要兒童椅和需要兒童餐具的文本信息
            val childChairText = if (isChildChairChecked) "需要兒童椅" else "不需要兒童椅"
            val childUtensilText = if (isChildUtensilChecked) "需要兒童餐具" else "不需要兒童餐具"

            bundle.putString("name", name)
            bundle.putString("spinnerSelection", "$spinner1SelectedItem 大 $spinner2SelectedItem 小")
            bundle.putString("childChairText", childChairText)
            bundle.putString("childUtensilText", childUtensilText)

            val secondIntent = Intent(this, guessnumber::class.java)
            secondIntent.putExtra("key", bundle)
            startActivity(secondIntent)
        }

    }
}
