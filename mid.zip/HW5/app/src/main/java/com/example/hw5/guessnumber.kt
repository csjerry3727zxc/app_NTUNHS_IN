package com.example.hw5

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

import java.util.*

class guessnumber : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guessnumber)

        // 获取从第一个活动传递的数据
        val bundle = intent.getBundleExtra("key")
        val name = bundle?.getString("name")
        val spinnerSelection = bundle?.getString("spinnerSelection")
        val childChairText = bundle?.getString("childChairText")
        val childUtensilText = bundle?.getString("childUtensilText")

        // 在 TextView 中显示姓名、Spinner 选项、需要兒童椅和需要兒童餐具的信息
        val textViewName = findViewById<TextView>(R.id.textViewName)
        val textViewSpinner = findViewById<TextView>(R.id.textViewSpinner)
        val textViewChildChair = findViewById<TextView>(R.id.textViewChildChair)
        val textViewChildUtensil = findViewById<TextView>(R.id.textViewChildUtensil)
        textViewName.text = "訂位電話: $name"
        textViewSpinner.text = "訂位人數: $spinnerSelection"
        textViewChildChair.text = " $childChairText"
        textViewChildUtensil.text = " $childUtensilText"

        val backButton = findViewById<Button>(R.id.btnBackToFirst)
        // 为返回按钮设置点击事件
        backButton.setOnClickListener {
            // 创建一个意图，用于返回到第一个活动
            val intent = Intent(this, MainActivity::class.java)
            // 启动第一个活动
            startActivity(intent)
        }
    }
}




