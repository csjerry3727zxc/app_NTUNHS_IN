package com.example.guessnumber

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.util.*
import com.example.guessnumber.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var handler: Handler
    private var secret = 0 // 移动secret变量到类级别

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        handler = Handler(Looper.getMainLooper())

        // 生成秘密数字
        resetSecret()

        binding.guessButton.setOnClickListener {
            val guessNum = binding.editText.text.toString().toIntOrNull()
            if (guessNum == null) {
                showToast("請輸入有效的數字")
                return@setOnClickListener
            }

            val validateNum = guessNum - secret
            val ansStr: String = when {
                validateNum > 0 -> {
                    "你猜得太大了，再小一點。範圍在1到${guessNum}之間。"
                }
                validateNum < 0 -> {
                    "你猜得太小了，再大一點。範圍在${guessNum}到100之間。"
                }
                else -> {
                    handler.postDelayed({
                        showToast("6秒後的操作執行了")
                    }, 6000)
                    "你猜對了歐"
                }
            }

            updateResult(ansStr)
        }




        binding.resetButton.setOnClickListener {
            resetSecret()
            updateResult("我們再猜一次!!")
        }
    }

    private fun resetSecret() {
        secret = Random().nextInt(100) + 1
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun updateResult(message: String) {
        binding.resultTextView.text = message
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
