import android.os.Handler
import android.os.Looper
import java.util.*

class NumberGuesser(private val listener: Listener) {
    private val handler: Handler = Handler(Looper.getMainLooper())
    private var secret = 0

    fun guessNumber(guess: Int) {
        val validateNum = guess - secret
        val ansStr: String = when {
            validateNum > 0 -> {
                "你猜得太大了，再小一點。範圍在1到${guess}之間。"
            }
            validateNum < 0 -> {
                "你猜得太小了，再大一點。範圍在${guess}到100之間。"
            }
            else -> {
                handler.postDelayed({
                    listener.onGuessResult("6秒後的操作執行了")
                }, 6000)
                "你猜對了歐"
            }
        }
        listener.onGuessResult(ansStr)
    }

    fun resetSecret() {
        secret = Random().nextInt(100) + 1
    }

    interface Listener {
        fun onGuessResult(result: String)
    }
}
