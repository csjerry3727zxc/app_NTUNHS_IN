import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.guessnumber.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), NumberGuesser.Listener {
    private lateinit var binding: ActivityMainBinding
    private lateinit var numberGuesser: NumberGuesser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 初始化 NumberGuesser
        numberGuesser = NumberGuesser(this)

        // 生成秘密數字
        numberGuesser.resetSecret()

        // 猜數字按鈕點擊監聽器
        binding.guessButton.setOnClickListener {
            val guessNum = binding.editText.text.toString().toIntOrNull()
            if (guessNum == null) {
                showToast("請輸入有效的數字")
                return@setOnClickListener
            }

            // 使用 NumberGuesser 進行猜數字
            numberGuesser.guessNumber(guessNum)
        }

        // 重置按鈕點擊監聽器
        binding.resetButton.setOnClickListener {
            numberGuesser.resetSecret()
            updateResult("我們再猜一次!!")
        }
    }

    // 顯示 Toast 訊息
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    // 從 NumberGuesser.Listener 中實現的方法，用於更新結果
    override fun onGuessResult(result: String) {
        updateResult(result)
    }

    // 更新結果的方法
    private fun updateResult(message: String) {
        binding.resultTextView.text = message
    }
}
